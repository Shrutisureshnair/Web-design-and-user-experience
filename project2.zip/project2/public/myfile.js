
  "use stict";

  (function () {

    const modal1 = document.querySelector('.mymodal');
    const open1 = document.querySelectorAll('.subscribe-btn');
    const close1 = document.querySelectorAll('.close');

    open1.forEach(op => {
      op.addEventListener('click', () => {
        modal1.showModal();
      });
    })

    close1.forEach(cls => {
      cls.addEventListener('click', () => {
        modal1.close();
      });
    })

    const form = document.querySelector('#form_id');
    const emailInput = document.querySelector('#email_id');
    const confirmEmailInput = document.querySelector('#confirm_email_id');


    emailInput.addEventListener('change', () => {
      const emailErr = document.querySelector('.email-inp');
      const emailValue = document.forms["form"]["email"].value;
      const emailValidation = /(^\S+@\S+$)/;
      let emailInputBorder = document.querySelector("#email_id");

      if (emailValue == "" || emailValue == null) {
       
        emailErr.innerText = "Email cannot be empty!";
      } else if (!emailValidation.test(emailValue)) {
       
        emailErr.innerText = "This field be a valid email address including a @";
      } else {
        emailInputBorder.setAttribute("style", "none");
        emailErr.innerText = "";
      }
    });

    confirmEmailInput.addEventListener('change', (event) => {
      const confirmEmailErr= document.querySelector('.email-check');
      const confirmEmailValue = document.forms["form"]["confirm_email"].value;
      const emailValue = document.forms["form"]["email"].value;


      let confirmEmailInputBorder = document.querySelector("#confirm_email_id");

      if (confirmEmailValue == "" || confirmEmailValue == null) {
        
        confirmEmailErr.innerText = "Confirm email cannot be empty";
      } else if (confirmEmailValue != emailValue) {
       
        confirmEmailErr.innerText = "Confirm email does not match with the email";
      } else {
        confirmEmailInputBorder.setAttribute("style", "none");
        confirmEmailErr.innerText = "";
      }
    });

    form.addEventListener('submit', (event) => {
      const emailErr = document.querySelector('.email-inp');
      const confirmEmailErr = document.querySelector('.email-check');

      const emailValue = document.forms["form"]["email"].value;
      const confirmEmailValue = document.forms["form"]["confirm_email"].value;

      let emailInputBorder = document.querySelector("#email_id");
      let confirmEmailInputBorder = document.querySelector("#confirm_email_id");

      let emailErrorText = "";
      const emailValidation = /(^\S+@\S+$)/;

      if (emailValue == "" || emailValue == null) {
       
        emailErrorText = "This field is required";
      } else if (!emailValidation.test(emailValue)) {
       
        emailErrorText = "Invalid email!";
      }

      emailErr.innerText = emailErrorText;

      let confirmEmailErrorText = "";

      if (emailValue != "") {
        if (confirmEmailValue == "" || confirmEmailValue == null) {
         
          confirmEmailErrorText = "This field must match the provided email address";
        } else if (confirmEmailValue != emailValue) {
         
          confirmEmailErrorText = "Confirm email does not match!";
        }
      }

      confirmEmailErr.innerText = confirmEmailErrorText;
      if (emailValue == "" || confirmEmailValue == "" || emailErrorText != "" || confirmEmailErrorText != "") {
        event.preventDefault();
      }
    });


    const menuTriggerButton = document.querySelector('button.icon-button');
  const menuPopup = document.querySelector('.menu');

  menuTriggerButton.addEventListener('click', function () {
    menuPopup.classList.toggle('show-menu');


  })();


})();